/**
 * =============================================================================
 *  ESSÊNCIA SUBLIME — IMPORTAÇÃO AUTOMATIZADA DE IMAGENS DO CATÁLOGO
 * =============================================================================
 *  O que este script faz, em ordem:
 *
 *   1. Lê /perfumes.json (lista de { nome, arquivo })
 *   2. Para cada perfume, pergunta à função getImageUrl() qual URL usar
 *      (essa função é o ÚNICO ponto que você precisa configurar — ver
 *      instruções na seção "CONFIGURAR A FONTE DE IMAGENS" logo abaixo)
 *   3. Baixa a imagem via Axios
 *   4. Valida se o conteúdo baixado é REALMENTE uma imagem (Sharp lê os
 *      metadados; se falhar, não é uma imagem válida)
 *   5. Converte para WebP, redimensiona para no máximo 1200px de largura
 *      (mantendo proporção) e otimiza a qualidade para web
 *   6. Salva em /images/perfumes/{arquivo}.webp
 *   7. Se não houver imagem (fonte não configurada, 404, arquivo inválido
 *      etc.) o perfume é registrado no relatório e o processamento CONTINUA
 *      — nada aqui derruba o script
 *   8. Ao final, grava /import-report.json e imprime um resumo no terminal
 *   9. Garante que /images/perfumes/placeholder.svg sempre exista,
 *      para o site nunca ficar com espaço vazio quando faltar uma foto
 *
 *  Este arquivo usa ES Modules (import/export), async/await em todo o
 *  pipeline, e todo bloco de risco (rede, disco, parsing de imagem) está
 *  isolado em try/catch para nunca interromper o lote inteiro por causa
 *  de um único perfume com problema.
 * =============================================================================
 */

import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';
import axios from 'axios';
import sharp from 'sharp';

// -----------------------------------------------------------------------------
// CAMINHOS DO PROJETO
// -----------------------------------------------------------------------------
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT_DIR = path.resolve(__dirname, '..');

const PERFUMES_JSON_PATH = path.join(ROOT_DIR, 'perfumes.json');
const IMAGE_SOURCES_PATH = path.join(ROOT_DIR, 'image-sources.json'); // opcional
const OUTPUT_DIR = path.join(ROOT_DIR, 'images', 'perfumes');
const REPORT_PATH = path.join(ROOT_DIR, 'import-report.json');
const PLACEHOLDER_PATH = path.join(OUTPUT_DIR, 'placeholder.svg');

// -----------------------------------------------------------------------------
// CONFIGURAÇÃO DE PROCESSAMENTO DE IMAGEM
// -----------------------------------------------------------------------------
const CONFIG = {
  maxWidth: 1200,        // largura máxima final, em pixels
  webpQuality: 82,       // 0-100 — 82 é um ótimo equilíbrio qualidade/peso
  downloadTimeoutMs: 15000,
  userAgent: 'EssenciaSublime-ImageImporter/1.0 (+https://essenciasublime.com)',
};

// =============================================================================
// CONFIGURAR A FONTE DE IMAGENS  ←  EDITE ESTA FUNÇÃO
// =============================================================================
// Este é o ÚNICO lugar do script que depende de "onde a foto vem".
// Ele recebe um perfume ({ nome, arquivo }) e deve devolver:
//   - uma string com a URL da imagem, OU
//   - null/undefined, se não houver imagem disponível para esse perfume
//     (nesse caso ele cai automaticamente em "não encontrados" no relatório)
//
// Por padrão, o script já resolve a URL usando um mapa manual opcional
// em /image-sources.json (veja /image-sources.example.json). Isso cobre o
// caso mais comum: você (ou o fornecedor) já tem os links das fotos.
//
// Para plugar uma fonte automática (API de busca de imagens, banco de
// imagens do distribuidor, scraping autorizado, etc.), implemente a
// chamada dentro do bloco indicado abaixo. Exemplos de integração comum:
//   • Google Custom Search API (Image Search)
//   • Bing Image Search API / SerpAPI
//   • API do próprio fornecedor/distribuidor de perfumes
//   • Um bucket S3 / CDN próprio, usando convenção de nomes
// =============================================================================
async function getImageUrl(perfume, imageSourcesMap) {
  // 1) Mapa manual (image-sources.json) tem prioridade — é a forma mais
  //    confiável de garantir a foto certa para o produto certo.
  if (imageSourcesMap && imageSourcesMap[perfume.arquivo]) {
    return imageSourcesMap[perfume.arquivo];
  }

  // 2) INTEGRAÇÃO AUTOMÁTICA — ative aqui a fonte de sua escolha.
  //    Exemplo (comentado) usando uma API de busca de imagens genérica:
  //
  //    const resposta = await axios.get('https://api.exemplo.com/search', {
  //      params: { q: `${perfume.nome} perfume frasco`, apiKey: process.env.IMAGE_API_KEY },
  //      timeout: CONFIG.downloadTimeoutMs,
  //    });
  //    return resposta.data?.results?.[0]?.url ?? null;

  // 3) Nenhuma fonte configurada para este perfume → não encontrado.
  return null;
}

// -----------------------------------------------------------------------------
// UTILITÁRIOS DE TERMINAL (log amigável, sem dependência extra)
// -----------------------------------------------------------------------------
const color = {
  green: (s) => `\x1b[32m${s}\x1b[0m`,
  red: (s) => `\x1b[31m${s}\x1b[0m`,
  yellow: (s) => `\x1b[33m${s}\x1b[0m`,
  gray: (s) => `\x1b[90m${s}\x1b[0m`,
  bold: (s) => `\x1b[1m${s}\x1b[0m`,
  gold: (s) => `\x1b[38;5;178m${s}\x1b[0m`,
};

function logStep(msg) {
  console.log(color.gray('  › ') + msg);
}
function logOk(msg) {
  console.log(color.green('  ✓ ') + msg);
}
function logWarn(msg) {
  console.log(color.yellow('  ⚠ ') + msg);
}
function logErr(msg) {
  console.log(color.red('  ✕ ') + msg);
}

// -----------------------------------------------------------------------------
// GARANTE QUE UM DIRETÓRIO EXISTA (cria recursivamente se necessário)
// -----------------------------------------------------------------------------
async function ensureDir(dirPath) {
  await fs.mkdir(dirPath, { recursive: true });
}

// -----------------------------------------------------------------------------
// CARREGA perfumes.json
// -----------------------------------------------------------------------------
async function loadPerfumes() {
  const raw = await fs.readFile(PERFUMES_JSON_PATH, 'utf-8');
  const data = JSON.parse(raw);

  if (!Array.isArray(data)) {
    throw new Error('perfumes.json deve conter um array de objetos { nome, arquivo }.');
  }
  for (const item of data) {
    if (!item.nome || !item.arquivo) {
      throw new Error(`Item inválido em perfumes.json: ${JSON.stringify(item)} — "nome" e "arquivo" são obrigatórios.`);
    }
  }
  return data;
}

// -----------------------------------------------------------------------------
// CARREGA image-sources.json, SE EXISTIR (é opcional)
// -----------------------------------------------------------------------------
async function loadImageSourcesMap() {
  try {
    const raw = await fs.readFile(IMAGE_SOURCES_PATH, 'utf-8');
    return JSON.parse(raw);
  } catch (err) {
    if (err.code === 'ENOENT') return {}; // arquivo não existe — tudo bem, é opcional
    logWarn(`image-sources.json existe mas não pôde ser lido (${err.message}). Ignorando.`);
    return {};
  }
}

// -----------------------------------------------------------------------------
// BAIXA UMA IMAGEM E RETORNA O BUFFER BRUTO
// -----------------------------------------------------------------------------
async function downloadImage(url) {
  const response = await axios.get(url, {
    responseType: 'arraybuffer',
    timeout: CONFIG.downloadTimeoutMs,
    headers: { 'User-Agent': CONFIG.userAgent },
    validateStatus: (status) => status === 200,
  });

  const contentType = response.headers['content-type'] || '';
  if (!contentType.startsWith('image/')) {
    throw new Error(`Content-Type inesperado: "${contentType}" (esperado image/*)`);
  }

  return Buffer.from(response.data);
}

// -----------------------------------------------------------------------------
// VALIDA SE O BUFFER É REALMENTE UMA IMAGEM DECODIFICÁVEL
// (usa o próprio Sharp: se ele conseguir ler os metadados, é uma imagem válida)
// -----------------------------------------------------------------------------
async function validateIsImage(buffer) {
  const metadata = await sharp(buffer).metadata(); // lança erro se não for imagem
  if (!metadata.width || !metadata.height) {
    throw new Error('Imagem sem dimensões legíveis.');
  }
  return metadata;
}

// -----------------------------------------------------------------------------
// CONVERTE PARA WEBP, REDIMENSIONA E OTIMIZA
// -----------------------------------------------------------------------------
async function processImageToWebp(buffer) {
  return sharp(buffer)
    .rotate() // corrige orientação EXIF automaticamente
    .resize({
      width: CONFIG.maxWidth,
      withoutEnlargement: true, // nunca aumenta imagens menores que 1200px
    })
    .webp({ quality: CONFIG.webpQuality })
    .toBuffer();
}

// -----------------------------------------------------------------------------
// PROCESSA UM ÚNICO PERFUME (baixar → validar → converter → salvar)
// Nunca lança erro para fora: qualquer falha é capturada e devolvida
// como resultado estruturado, para o loop principal nunca parar.
// -----------------------------------------------------------------------------
async function processPerfume(perfume, imageSourcesMap) {
  const outputPath = path.join(OUTPUT_DIR, `${perfume.arquivo}.webp`);

  try {
    const url = await getImageUrl(perfume, imageSourcesMap);

    if (!url) {
      logWarn(`${perfume.nome} — nenhuma fonte de imagem configurada`);
      return { status: 'nao-encontrado', perfume, motivo: 'Nenhuma URL disponível para este perfume' };
    }

    logStep(`${perfume.nome} — baixando de ${url}`);
    const rawBuffer = await downloadImage(url);

    const metadata = await validateIsImage(rawBuffer);

    const webpBuffer = await processImageToWebp(rawBuffer);
    await fs.writeFile(outputPath, webpBuffer);

    logOk(`${perfume.nome} → ${perfume.arquivo}.webp (${metadata.width}x${metadata.height} → máx ${CONFIG.maxWidth}px, ${(webpBuffer.length / 1024).toFixed(1)}kb)`);

    return {
      status: 'encontrado',
      perfume,
      url,
      arquivoSalvo: `${perfume.arquivo}.webp`,
      tamanhoOriginal: `${metadata.width}x${metadata.height}`,
      tamanhoArquivoKb: Number((webpBuffer.length / 1024).toFixed(1)),
    };
  } catch (err) {
    logErr(`${perfume.nome} — erro: ${err.message}`);
    return { status: 'erro', perfume, erro: err.message };
  }
}

// -----------------------------------------------------------------------------
// GERA O PLACEHOLDER PREMIUM EM SVG (executa sempre, sobrescreve o anterior)
// Fundo branco, borda fina cinza, ícone minimalista, texto "Imagem em atualização"
// -----------------------------------------------------------------------------
async function generatePlaceholderSvg() {
  const svg = `<svg width="800" height="1067" viewBox="0 0 800 1067" xmlns="http://www.w3.org/2000/svg">
  <rect x="1" y="1" width="798" height="1065" fill="#FFFFFF" stroke="#D9D9D6" stroke-width="1.5"/>
  <g transform="translate(345,430)" fill="none" stroke="#B0ACA1" stroke-width="3" stroke-linejoin="round">
    <rect x="41" y="4" width="18" height="12" rx="2" fill="#B0ACA1" stroke="none"/>
    <rect x="45" y="14" width="10" height="8" fill="#B0ACA1" stroke="none"/>
    <path d="M30 22 C30 22 24 34 24 46 L24 122 C24 130 34 136 50 136 C66 136 76 130 76 122 L76 46 C76 34 70 22 70 22 Z"/>
    <line x1="34" y1="72" x2="66" y2="72"/>
  </g>
  <text x="400" y="660" font-family="Georgia, 'Times New Roman', serif" font-size="26" fill="#8A8578" text-anchor="middle" letter-spacing="1">Imagem em atualização</text>
</svg>`;

  await fs.writeFile(PLACEHOLDER_PATH, svg, 'utf-8');
}

// -----------------------------------------------------------------------------
// GRAVA O RELATÓRIO FINAL EM import-report.json
// -----------------------------------------------------------------------------
async function writeReport(results, startTime) {
  const encontrados = results.filter((r) => r.status === 'encontrado');
  const naoEncontrados = results.filter((r) => r.status === 'nao-encontrado');
  const erros = results.filter((r) => r.status === 'erro');

  const report = {
    executadoEm: new Date().toISOString(),
    tempoExecucaoSegundos: Number(((Date.now() - startTime) / 1000).toFixed(2)),
    totalPerfumes: results.length,
    quantidadeImportada: encontrados.length,
    encontrados: encontrados.map((r) => ({
      nome: r.perfume.nome,
      arquivo: r.arquivoSalvo,
      url: r.url,
      dimensoesOriginais: r.tamanhoOriginal,
      tamanhoKb: r.tamanhoArquivoKb,
    })),
    naoEncontrados: naoEncontrados.map((r) => ({
      nome: r.perfume.nome,
      arquivo: `${r.perfume.arquivo}.webp`,
      motivo: r.motivo,
    })),
    erros: erros.map((r) => ({
      nome: r.perfume.nome,
      arquivo: `${r.perfume.arquivo}.webp`,
      erro: r.erro,
    })),
  };

  await fs.writeFile(REPORT_PATH, JSON.stringify(report, null, 2), 'utf-8');
  return report;
}

// -----------------------------------------------------------------------------
// IMPRIME O RESUMO FINAL NO TERMINAL
// -----------------------------------------------------------------------------
function printSummary(report) {
  console.log('\n' + color.bold(color.gold('═'.repeat(60))));
  console.log(color.bold(color.gold('  ESSÊNCIA SUBLIME — RELATÓRIO DE IMPORTAÇÃO')));
  console.log(color.bold(color.gold('═'.repeat(60))));
  console.log(`  Total de perfumes processados : ${color.bold(report.totalPerfumes)}`);
  console.log(`  ${color.green('Importados com sucesso')}       : ${color.bold(report.quantidadeImportada)}`);
  console.log(`  ${color.yellow('Sem imagem encontrada')}        : ${color.bold(report.naoEncontrados.length)}`);
  console.log(`  ${color.red('Erros durante o processo')}     : ${color.bold(report.erros.length)}`);
  console.log(`  Tempo de execução              : ${report.tempoExecucaoSegundos}s`);
  console.log(color.gray(`\n  Relatório completo salvo em: import-report.json`));
  console.log(color.gray(`  Placeholder disponível em : images/perfumes/placeholder.svg`));
  console.log(color.bold(color.gold('═'.repeat(60))) + '\n');
}

// -----------------------------------------------------------------------------
// FUNÇÃO PRINCIPAL — orquestra todo o pipeline
// -----------------------------------------------------------------------------
async function main() {
  const startTime = Date.now();

  console.log(color.bold('\n🌸 Essência Sublime — Importação automatizada de imagens\n'));

  try {
    await ensureDir(OUTPUT_DIR);
    logStep('Diretório de saída pronto: images/perfumes/');

    await generatePlaceholderSvg();
    logStep('Placeholder premium gerado/atualizado: placeholder.svg');

    const perfumes = await loadPerfumes();
    logStep(`${perfumes.length} perfumes carregados de perfumes.json\n`);

    const imageSourcesMap = await loadImageSourcesMap();

    // Processa em série (mais respeitoso com a fonte de imagens que em
    // paralelo total). Se quiser paralelizar, troque por Promise.all em lotes.
    const results = [];
    for (const perfume of perfumes) {
      const result = await processPerfume(perfume, imageSourcesMap);
      results.push(result);
    }

    const report = await writeReport(results, startTime);
    printSummary(report);

    if (report.erros.length > 0) {
      console.log(color.yellow('  Atenção: alguns perfumes tiveram erro durante o processo.'));
      console.log(color.yellow('  Veja os detalhes em import-report.json → "erros".\n'));
    }
    if (report.naoEncontrados.length > 0) {
      console.log(color.gray('  Os perfumes sem imagem usarão automaticamente o placeholder no site.\n'));
    }
  } catch (fatalErr) {
    // Erro fatal = algo impediu o script de sequer começar (ex.: perfumes.json
    // ausente/ inválido, ou impossibilidade de criar as pastas de saída).
    console.error(color.red(`\n✕ Erro fatal: ${fatalErr.message}\n`));
    process.exitCode = 1;
  }
}

main();
